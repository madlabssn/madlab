package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    Button submitbtn;
    LinearLayout quizView,scoreView;
    RadioGroup ans1,ans2;
    TextView scoreTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);



        submitbtn = findViewById(R.id.submit_btn);
        quizView = findViewById(R.id.quizLayout);
        scoreView = findViewById(R.id.scoreLayout);

        ans1 = findViewById(R.id.answer1);
        ans2 = findViewById(R.id.answer2);
        scoreTV = findViewById(R.id.scoreTextView);

        quizView.setVisibility(View.VISIBLE);
        scoreView.setVisibility(View.INVISIBLE);

        Toast.makeText(getApplicationContext(),"Test Started",Toast.LENGTH_SHORT).show();

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int score = 0;

                if(ans1.getCheckedRadioButtonId() == R.id.option12){
                    score += 10;
                }

                if(ans2.getCheckedRadioButtonId() == R.id.option21){
                    score += 10;
                }

                quizView.setVisibility(View.INVISIBLE);
                scoreView.setVisibility(View.VISIBLE);

                scoreTV.setText("Your Score is "+ String.valueOf(score));

                Toast.makeText(getApplicationContext(),"Test Ended. Thank you for Taking Test",Toast.LENGTH_LONG).show();
            }
        });


    }
}