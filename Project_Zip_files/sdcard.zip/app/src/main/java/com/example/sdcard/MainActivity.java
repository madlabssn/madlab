package com.example.sdcard;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2,e3;
    Button savebt,readbt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText) findViewById(R.id.et1);
        e2=(EditText) findViewById(R.id.et2);
        e3=(EditText) findViewById(R.id.et3);
        savebt=(Button) findViewById(R.id.button1);
        readbt=(Button) findViewById(R.id.button2);
        savebt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                String filename=e1.getText().toString();
                String data=e2.getText().toString();
                FileOutputStream fos;
                try{
                    fos=openFileOutput(filename, Context.MODE_APPEND);
                    fos.write(data.getBytes());
                    fos.close();
                    Toast.makeText(getApplicationContext(), filename+"saved", Toast.LENGTH_LONG).show();
                }catch(FileNotFoundException e){
                    e.printStackTrace();
                }catch(IOException e){
                    e.printStackTrace();
                }
            }
        });
        readbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                String filename=e1.getText().toString();
                StringBuffer stringBuffer=new StringBuffer();
                try{
                    BufferedReader inputReader=new BufferedReader(new InputStreamReader(openFileInput(filename)));
                    String inputString;
                    while((inputString=inputReader.readLine())!=null){
                        stringBuffer.append(inputString+"\n");
                    }
                }catch(IOException e){
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(), stringBuffer.toString(), Toast.LENGTH_LONG).show();
                e3.setText(stringBuffer.toString().trim());
            }
        });
    }
}