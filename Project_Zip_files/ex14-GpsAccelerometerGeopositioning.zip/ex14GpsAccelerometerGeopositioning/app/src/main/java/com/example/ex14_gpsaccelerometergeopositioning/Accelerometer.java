package com.example.ex14_gpsaccelerometergeopositioning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class Accelerometer extends AppCompatActivity {

    private float xAcc = (float) 0.0, yAcc = (float) 0.0, zAcc = (float) 0.0;
    private int sensorAccuracy = 0;
    void updateTextView(){
        TextView tv = findViewById(R.id.accTextView);
        String toDisplay = "X-axis Acceleration: " + xAcc + "\n\nY-axis Acceleration: " + yAcc
                + "\n\nZ-axis Acceleration: "+ zAcc
                + "\n\nSensor Accuracy: " + sensorAccuracy;
        tv.setText(toDisplay);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accelerometer);
        SensorManager sensorManager = (SensorManager)
                getSystemService(Context.SENSOR_SERVICE);
        Sensor sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        SensorEventListener sel = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                xAcc = event.values[0];
                yAcc = event.values[1];
                zAcc = event.values[2];
                updateTextView();
            }
            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {
                sensorAccuracy = accuracy;
                updateTextView();
            }
        };
        sensorManager.registerListener(sel, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

}