// Our movie model
class Movie {
  final int id;
  final double rating;
  final String title, poster;

  Movie({
    this.poster,
    this.title,
    this.id,
    this.rating,
  });
}

// our demo data movie data
List<Movie> movies = [
  Movie(
    id: 1,
    title: "Bloodshot",
    poster: "assets/images/poster_1.jpg",
    rating: 7.3,
  ),
  Movie(
    id: 2,
    title: "Ford v Ferrari ",
    poster: "assets/images/poster_2.jpg",
    rating: 8.2,
  ),
  Movie(
    id: 3,
    title: "Onward",
    poster: "assets/images/poster_3.jpg",
    rating: 7.6,
  ),
];
